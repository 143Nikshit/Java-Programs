package MobileShop;

public class apple {
	void printThanks()
	{
		System.out.print("Thanks for buying : ");
	}


}
